<?php
// public/create.php
require_once __DIR__ . '/../config/db.php';

$errors = [];
$name = '';
$category = 'Umum';
$price = '';
$stock = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Normalisasi Input
    $name     = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? 'Umum');
    $priceRaw = trim($_POST['price'] ?? '');
    $stockRaw = trim($_POST['stock'] ?? '');

    // 2. Validasi Server-Side
    if (mb_strlen($name) < 3) {
        $errors['name'] = 'Nama produk minimal 3 karakter.';
    }

    if (empty($category)) {
        $category = 'Umum';
    }

    $price = filter_var($priceRaw, FILTER_VALIDATE_FLOAT);
    if ($price === false || $price <= 0) {
        $errors['price'] = 'Harga harus berupa angka lebih dari 0.';
    }

    $stock = filter_var($stockRaw, FILTER_VALIDATE_INT);
    if ($stock === false || $stock < 0) {
        $errors['stock'] = 'Stok harus berupa angka bulat dan tidak boleh negatif.';
    }

    // Cek Unik Nama Produk di Database jika belum ada error nama
    if (empty($errors['name'])) {
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE name = :name");
        $checkStmt->execute(['name' => $name]);
        if ($checkStmt->fetchColumn() > 0) {
            $errors['name'] = 'Nama produk sudah terdaftar. Gunakan nama lain.';
        }
    }

    // 3. Jika Validasi Lolos -> PDO Prepared Statement -> PRG Pattern
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO products (name, category, price, stock) VALUES (:name, :category, :price, :stock)");
            $stmt->execute([
                'name'     => $name,
                'category' => $category,
                'price'    => $price,
                'stock'    => $stock
            ]);

            // Post-Redirect-Get (PRG)
            header("Location: index.php?status=created");
            exit;
        } catch (\PDOException $e) {
            $errors['general'] = 'Gagal menyimpan ke database: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk Baru - Product Manager</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

    <header class="navbar">
        <a href="index.php" class="brand">ProductManager</a>
        <a href="index.php" class="btn btn-secondary">← Kembali</a>
    </header>

    <main class="container">
        <div class="form-container">
            <h2 style="margin-top: 0; margin-bottom: 1.5rem;">Tambah Produk Baru</h2>

            <?php if (!empty($errors['general'])): ?>
                <div class="alert alert-error">
                    <?= htmlspecialchars($errors['general'], ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="create.php">
                <!-- Nama Produk -->
                <div class="form-group">
                    <label for="name">Nama Produk *</label>
                    <input type="text" id="name" name="name" class="form-control" 
                           value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" 
                           placeholder="Contoh: Laptop Pro 15 Inch" required minlength="3">
                    <?php if (!empty($errors['name'])): ?>
                        <div class="form-error"><?= htmlspecialchars($errors['name'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Kategori -->
                <div class="form-group">
                    <label for="category">Kategori *</label>
                    <input type="text" id="category" name="category" class="form-control" 
                           value="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>" 
                           placeholder="Contoh: Elektronik, Aksesori, dll." required>
                </div>

                <!-- Harga -->
                <div class="form-group">
                    <label for="price">Harga (Rp) *</label>
                    <input type="number" id="price" name="price" step="0.01" min="1" class="form-control" 
                           value="<?= htmlspecialchars($price, ENT_QUOTES, 'UTF-8') ?>" 
                           placeholder="Contoh: 1500000" required>
                    <?php if (!empty($errors['price'])): ?>
                        <div class="form-error"><?= htmlspecialchars($errors['price'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Stok -->
                <div class="form-group">
                    <label for="stock">Stok *</label>
                    <input type="number" id="stock" name="stock" min="0" class="form-control" 
                           value="<?= htmlspecialchars($stock, ENT_QUOTES, 'UTF-8') ?>" 
                           placeholder="Contoh: 10" required>
                    <?php if (!empty($errors['stock'])): ?>
                        <div class="form-error"><?= htmlspecialchars($errors['stock'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">Simpan Produk</button>
                    <a href="index.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </main>

</body>
</html>
