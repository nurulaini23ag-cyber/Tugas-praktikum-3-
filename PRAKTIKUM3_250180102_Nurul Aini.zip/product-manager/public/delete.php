<?php
// public/delete.php
require_once __DIR__ . '/../config/db.php';

// Pastikan hanya menerima request dengan method POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit("Method Not Allowed");
}

// 1. Validasi Token CSRF (Proteksi Keamanan Modul 4)
$csrfToken = $_POST['csrf'] ?? '';
if (!hash_equals($_SESSION['csrf'] ?? '', $csrfToken)) {
    http_response_code(403);
    exit("403 Forbidden: Token CSRF tidak valid.");
}

// 2. Validasi Input ID
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if ($id) {
    // 3. Prepared Statement DELETE
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = :id");
    $stmt->execute(['id' => $id]);
}

// 4. Redirect ke index (Pola PRG)
header("Location: index.php?status=deleted");
exit;
