<?php
// public/index.php
require_once __DIR__ . '/../config/db.php';

// Fitur Search / Filter via GET
$search = trim($_GET['q'] ?? '');

if (!empty($search)) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE name LIKE :q OR category LIKE :q ORDER BY id DESC");
    $stmt->execute(['q' => "%{$search}%"]);
} else {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
}

$products = $stmt->fetchAll();

// Pesan notifikasi berdasarkan parameter status (Pola PRG)
$status = $_GET['status'] ?? '';
$message = '';
$alertClass = 'alert-success';

if ($status === 'created') {
    $message = 'Produk baru berhasil ditambahkan!';
} elseif ($status === 'updated') {
    $message = 'Data produk berhasil diperbarui!';
} elseif ($status === 'deleted') {
    $message = 'Produk berhasil dihapus!';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Manager - Pemrograman Web</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

    <header class="navbar">
        <a href="index.php" class="brand">ProductManager</a>
        <a href="create.php" class="btn btn-primary">+ Tambah Produk</a>
    </header>

    <main class="container">
        <?php if (!empty($message)): ?>
            <div class="alert <?= $alertClass ?>">
                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <div class="header-section">
            <div>
                <h1>Daftar Produk</h1>
                <p style="color: var(--text-muted); margin:0;">Kelola persediaan dan informasi produk toko Anda.</p>
            </div>

            <!-- Form Pencarian GET -->
            <form method="GET" action="index.php" class="search-form">
                <input type="text" name="q" value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>" placeholder="Cari produk atau kategori...">
                <button type="submit" class="btn btn-secondary">Cari</button>
                <?php if (!empty($search)): ?>
                    <a href="index.php" class="btn btn-secondary">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <!-- Flexbox Cards Layout -->
        <?php if (empty($products)): ?>
            <div class="empty-state">
                <h3>Belum ada produk ditemukan</h3>
                <p>Silakan tambah produk baru atau ubah kata kunci pencarian Anda.</p>
                <a href="create.php" class="btn btn-primary" style="margin-top: 1rem;">Tambah Produk Sekarang</a>
            </div>
        <?php else: ?>
            <div class="products-grid">
                <?php foreach ($products as $p): ?>
                    <div class="product-card">
                        <div>
                            <div class="card-header">
                                <h2 class="product-title"><?= htmlspecialchars($p['name'], ENT_QUOTES, 'UTF-8') ?></h2>
                                <span class="badge"><?= htmlspecialchars($p['category'], ENT_QUOTES, 'UTF-8') ?></span>
                            </div>

                            <div class="product-price">
                                Rp <?= number_format($p['price'], 0, ',', '.') ?>
                            </div>

                            <div class="product-stock">
                                Stok: <strong><?= (int)$p['stock'] ?></strong> unit
                            </div>
                        </div>

                        <div class="card-actions">
                            <a href="edit.php?id=<?= (int)$p['id'] ?>" class="btn btn-secondary btn-sm" style="flex: 1;">Edit</a>
                            
                            <!-- Form Delete via POST + CSRF Token -->
                            <form action="delete.php" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus produk ini?');" style="flex: 1;">
                                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
                                <button type="submit" class="btn btn-danger btn-sm" style="width: 100%;">Hapus</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

</body>
</html>
