<?php
// public/edit.php
require_once __DIR__ . '/../config/db.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
}

if (!$id) {
    header("Location: index.php");
    exit;
}

// Ambil data produk awal dari Database
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = :id");
$stmt->execute(['id' => $id]);
$product = $stmt->fetch();

if (!$product) {
    header("Location: index.php");
    exit;
}

$errors = [];
$name     = $product['name'];
$category = $product['category'];
$price    = $product['price'];
$stock    = $product['stock'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Normalisasi Input
    $name     = trim($_POST['name'] ?? '');
    $category = trim($_POST['category'] ?? 'Umum');
    $priceRaw = trim($_POST['price'] ?? '');
    $stockRaw = trim($_POST['stock'] ?? '');

    // 2. Validasi Server-Side
    if (mb_strlen($name) < 3) {
        $errors['name'] = 'Nama produk minimal 3 karakter.';
    }

    if (empty($category)) {
        $category = 'Umum';
    }

    $price = filter_var($priceRaw, FILTER_VALIDATE_FLOAT);
    if ($price === false || $price <= 0) {
        $errors['price'] = 'Harga harus berupa angka lebih dari 0.';
    }

    $stock = filter_var($stockRaw, FILTER_VALIDATE_INT);
    if ($stock === false || $stock < 0) {
        $errors['stock'] = 'Stok harus berupa angka bulat dan tidak boleh negatif.';
    }

    // Cek Unik Nama Produk (abaikan ID yang sedang diedit)
    if (empty($errors['name'])) {
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE name = :name AND id != :id");
        $checkStmt->execute(['name' => $name, 'id' => $id]);
        if ($checkStmt->fetchColumn() > 0) {
            $errors['name'] = 'Nama produk sudah digunakan oleh produk lain.';
        }
    }

    // 3. Jika Valid -> Execute UPDATE -> PRG Pattern
    if (empty($errors)) {
        try {
            $updateStmt = $pdo->prepare("UPDATE products SET name = :name, category = :category, price = :price, stock = :stock WHERE id = :id");
            $updateStmt->execute([
                'name'     => $name,
                'category' => $category,
                'price'    => $price,
                'stock'    => $stock,
                'id'       => $id
            ]);

            header("Location: index.php?status=updated");
            exit;
        } catch (\PDOException $e) {
            $errors['general'] = 'Gagal memperbarui database: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk - Product Manager</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

    <header class="navbar">
        <a href="index.php" class="brand">ProductManager</a>
        <a href="index.php" class="btn btn-secondary">← Kembali</a>
    </header>

    <main class="container">
        <div class="form-container">
            <h2 style="margin-top: 0; margin-bottom: 1.5rem;">Edit Produk</h2>

            <?php if (!empty($errors['general'])): ?>
                <div class="alert alert-error">
                    <?= htmlspecialchars($errors['general'], ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="edit.php?id=<?= (int)$id ?>">
                <input type="hidden" name="id" value="<?= (int)$id ?>">

                <!-- Nama Produk -->
                <div class="form-group">
                    <label for="name">Nama Produk *</label>
                    <input type="text" id="name" name="name" class="form-control" 
                           value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" required minlength="3">
                    <?php if (!empty($errors['name'])): ?>
                        <div class="form-error"><?= htmlspecialchars($errors['name'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Kategori -->
                <div class="form-group">
                    <label for="category">Kategori *</label>
                    <input type="text" id="category" name="category" class="form-control" 
                           value="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>" required>
                </div>

                <!-- Harga -->
                <div class="form-group">
                    <label for="price">Harga (Rp) *</label>
                    <input type="number" id="price" name="price" step="0.01" min="1" class="form-control" 
                           value="<?= htmlspecialchars($price, ENT_QUOTES, 'UTF-8') ?>" required>
                    <?php if (!empty($errors['price'])): ?>
                        <div class="form-error"><?= htmlspecialchars($errors['price'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <!-- Stok -->
                <div class="form-group">
                    <label for="stock">Stok *</label>
                    <input type="number" id="stock" name="stock" min="0" class="form-control" 
                           value="<?= htmlspecialchars($stock, ENT_QUOTES, 'UTF-8') ?>" required>
                    <?php if (!empty($errors['stock'])): ?>
                        <div class="form-error"><?= htmlspecialchars($errors['stock'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>
                </div>

                <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">Perbarui Produk</button>
                    <a href="index.php" class="btn btn-secondary">Batal</a>
                </div>
            </form>
        </div>
    </main>

</body>
</html>
