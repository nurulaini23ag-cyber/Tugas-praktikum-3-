<?php
// config/db.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inisialisasi Token CSRF jika belum ada
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$host = 'localhost';
$db   = 'store_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("<div style='padding:20px; font-family:sans-serif; color:#721c24; background:#f8d7da; border:1px solid #f5c6cb; border-radius:8px; margin:20px;'>
            <h3>Koneksi Database Gagal!</h3>
            <p>Pastikan MySQL server sudah berjalan di XAMPP/Laragon dan database <strong>store_db</strong> sudah di-import.</p>
            <p><small>Detail Error: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . "</small></p>
         </div>");
}
