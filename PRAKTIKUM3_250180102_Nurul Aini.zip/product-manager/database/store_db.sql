CREATE DATABASE IF NOT EXISTS store_db;
USE store_db;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    category VARCHAR(50) NOT NULL DEFAULT 'Umum',
    price DECIMAL(12,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data Awal (Seed Data)
INSERT INTO products (name, category, price, stock) VALUES
('Laptop Pro 15 Inch', 'Elektronik', 15000000.00, 10),
('Mouse Wireless Silent', 'Aksesori', 250000.00, 45),
('Keyboard Mechanical RGB', 'Aksesori', 850000.00, 20),
('Monitor 27 Inch 4K', 'Elektronik', 4200000.00, 8),
('Desk Pad Premium XL', 'Aksesori', 120000.00, 30)
ON DUPLICATE KEY UPDATE name=name;
